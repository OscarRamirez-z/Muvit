#!/bin/bash
echo "================================================"
echo "  Muvit - Sistema de Gestión de Cocinas"
echo "================================================"
echo ""
python3 run.py || python run.py
