import os
import sqlite3
import json
import hashlib
import hmac
import base64
import datetime
import secrets
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory, g
import jwt

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
DB_PATH    = os.path.join(BASE_DIR, "instance", "cocina.db")
SECRET_FILE = os.path.join(BASE_DIR, "instance", "secret.key")

os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)

if os.environ.get("SECRET_KEY"):
    SECRET_KEY = os.environ["SECRET_KEY"]
elif os.path.exists(SECRET_FILE):
    with open(SECRET_FILE, "r") as f:
        SECRET_KEY = f.read().strip()
else:
    SECRET_KEY = secrets.token_hex(32)
    with open(SECRET_FILE, "w") as f:
        f.write(SECRET_KEY)

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = SECRET_KEY

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exc=None):
    db = g.pop("db", None)
    if db:
        db.close()

def query(sql, params=(), one=False, commit=False):
    db = get_db()
    cur = db.execute(sql, params)
    if commit:
        db.commit()
        return cur.lastrowid
    rv = cur.fetchone() if one else cur.fetchall()
    return (dict(rv) if rv else None) if one else [dict(r) for r in rv]

def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    key  = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260000)
    return f"{salt}${base64.b64encode(key).decode()}"

def check_password(password: str, stored: str) -> bool:
    try:
        salt, encoded = stored.split("$", 1)
        key = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260000)
        return hmac.compare_digest(base64.b64encode(key).decode(), encoded)
    except Exception:
        return False

def create_token(user_id: int, role: str) -> str:
    payload = {
        "sub": str(user_id),
        "role": role,
        "exp":  datetime.datetime.utcnow() + datetime.timedelta(hours=8),
        "iat":  datetime.datetime.utcnow(),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def decode_token(token: str):
    return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Token requerido"}), 401
        try:
            data = decode_token(auth.split(" ", 1)[1])
            g.user_id   = data["sub"]
            g.user_role = data["role"]
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Sesión expirada"}), 401
        except Exception:
            return jsonify({"error": "Token inválido"}), 401
        return f(*args, **kwargs)
    return decorated

def roles_required(*roles):
    def decorator(f):
        @wraps(f)
        @token_required
        def decorated(*args, **kwargs):
            if g.user_role not in roles:
                return jsonify({"error": "Sin permiso"}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator

# ─── db ──────────────────────────────────────────────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    name     TEXT NOT NULL,
    email    TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role     TEXT NOT NULL DEFAULT 'Cliente',
    active   INTEGER NOT NULL DEFAULT 1,
    created  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
    id   INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS products (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    category_id INTEGER NOT NULL REFERENCES categories(id),
    price       REAL NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    created_by   INTEGER NOT NULL REFERENCES users(id),
    status       TEXT NOT NULL DEFAULT 'pendiente',
    notes        TEXT,
    delivered_by INTEGER REFERENCES users(id),
    created      TEXT NOT NULL DEFAULT (datetime('now')),
    updated      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity   INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS ingredients (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    name  TEXT NOT NULL UNIQUE,
    unit  TEXT NOT NULL DEFAULT 'unidad',
    stock REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS recipes (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    ingredient_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
    quantity      REAL NOT NULL DEFAULT 1,
    UNIQUE(product_id, ingredient_id)
);

CREATE TABLE IF NOT EXISTS inventory_movements (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ingredient_id INTEGER NOT NULL REFERENCES ingredients(id),
    type          TEXT NOT NULL,
    quantity      REAL NOT NULL,
    note          TEXT,
    created_by    INTEGER REFERENCES users(id),
    created       TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript(SCHEMA)
        db.commit()
        existing = query("SELECT id FROM users WHERE role='Admin' LIMIT 1", one=True)
        if not existing:
            pw = hash_password("admin123")
            query(
                "INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)",
                ("Administrador", "admin@cocina.com", pw, "Admin"),
                commit=True
            )
            print("✅ Admin creado: admin@cocina.com / admin123")


@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    email    = (data.get("email") or "").strip().lower()
    password = (data.get("password") or "").strip()
    if not email or not password:
        return jsonify({"error": "Email y contraseña requeridos"}), 400
    user = query("SELECT * FROM users WHERE email=? AND active=1", (email,), one=True)
    if not user or not check_password(password, user["password"]):
        return jsonify({"error": "Credenciales inválidas"}), 401
    token = create_token(user["id"], user["role"])
    return jsonify({"token": token, "user": {
        "id": user["id"], "name": user["name"],
        "email": user["email"], "role": user["role"]
    }})

@app.route("/api/auth/me", methods=["GET"])
@token_required
def me():
    user = query("SELECT id,name,email,role FROM users WHERE id=?", (g.user_id,), one=True)
    if not user:
        return jsonify({"error": "Usuario no encontrado"}), 404
    return jsonify(user)


@app.route("/api/users", methods=["GET"])
@roles_required("Admin")
def get_users():
    users = query("SELECT id,name,email,role,active,created FROM users ORDER BY name")
    return jsonify(users)

@app.route("/api/users", methods=["POST"])
@roles_required("Admin")
def create_user():
    d = request.get_json() or {}
    name     = (d.get("name") or "").strip()
    email    = (d.get("email") or "").strip().lower()
    password = (d.get("password") or "").strip()
    role     = (d.get("role") or "Cocina").strip()
    if not name or not email or not password:
        return jsonify({"error": "Todos los campos son requeridos"}), 400
    if role not in ("Admin", "Cocina", "Repartidor", "Cliente"):
        return jsonify({"error": "Rol inválido"}), 400
    if query("SELECT id FROM users WHERE email=?", (email,), one=True):
        return jsonify({"error": "Email ya registrado"}), 409
    pw = hash_password(password)
    uid = query("INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)",
                (name, email, pw, role), commit=True)
    return jsonify({"id": uid, "message": "Usuario creado"}), 201

@app.route("/api/users/<int:uid>", methods=["PUT"])
@roles_required("Admin")
def update_user(uid):
    d = request.get_json() or {}
    if uid == g.user_id and d.get("role") and d["role"] != "Admin":
        return jsonify({"error": "No puedes cambiar tu propio rol"}), 400
    fields, vals = [], []
    if d.get("name"):
        fields.append("name=?"); vals.append(d["name"].strip())
    if d.get("role") and d["role"] in ("Admin", "Cocina", "Repartidor", "Cliente"):
        fields.append("role=?"); vals.append(d["role"])
    if d.get("password"):
        fields.append("password=?"); vals.append(hash_password(d["password"]))
    if "active" in d:
        fields.append("active=?"); vals.append(1 if d["active"] else 0)
    if not fields:
        return jsonify({"error": "Nada que actualizar"}), 400
    vals.append(uid)
    query(f"UPDATE users SET {','.join(fields)} WHERE id=?", vals, commit=True)
    return jsonify({"message": "Usuario actualizado"})

@app.route("/api/users/<int:uid>", methods=["DELETE"])
@roles_required("Admin")
def delete_user(uid):
    if uid == g.user_id:
        return jsonify({"error": "No puedes eliminarte a ti mismo"}), 400
    query("DELETE FROM users WHERE id=?", (uid,), commit=True)
    return jsonify({"message": "Usuario eliminado"})

@app.route("/api/categories", methods=["GET"])
@token_required
def get_categories():
    cats = query("SELECT * FROM categories ORDER BY name")
    return jsonify(cats)

@app.route("/api/categories", methods=["POST"])
@roles_required("Admin")
def create_category():
    d = request.get_json() or {}
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify({"error": "Nombre requerido"}), 400
    cid = query("INSERT INTO categories (name) VALUES (?)", (name,), commit=True)
    return jsonify({"id": cid, "name": name}), 201

@app.route("/api/categories/<int:cid>", methods=["PUT"])
@roles_required("Admin")
def update_category(cid):
    d = request.get_json() or {}
    name = (d.get("name") or "").strip()
    if not name:
        return jsonify({"error": "Nombre requerido"}), 400
    query("UPDATE categories SET name=? WHERE id=?", (name, cid), commit=True)
    return jsonify({"message": "Categoría actualizada"})

@app.route("/api/categories/<int:cid>", methods=["DELETE"])
@roles_required("Admin")
def delete_category(cid):
    has = query("SELECT id FROM products WHERE category_id=? LIMIT 1", (cid,), one=True)
    if has:
        return jsonify({"error": "Categoría tiene productos asociados"}), 400
    query("DELETE FROM categories WHERE id=?", (cid,), commit=True)
    return jsonify({"message": "Categoría eliminada"})

@app.route("/api/products", methods=["GET"])
@token_required
def get_products():
    only_active = request.args.get("active")
    if only_active == "1":
        rows = query("""
            SELECT p.*, c.name as category_name
            FROM products p JOIN categories c ON p.category_id=c.id
            WHERE p.active=1 ORDER BY c.name, p.name
        """)
    else:
        rows = query("""
            SELECT p.*, c.name as category_name
            FROM products p JOIN categories c ON p.category_id=c.id
            ORDER BY c.name, p.name
        """)
    return jsonify(rows)

@app.route("/api/products", methods=["POST"])
@roles_required("Admin")
def create_product():
    d = request.get_json() or {}
    name = (d.get("name") or "").strip()
    cat  = d.get("category_id")
    price = d.get("price", 0)
    if not name or not cat:
        return jsonify({"error": "Nombre y categoría requeridos"}), 400
    pid = query("INSERT INTO products (name,category_id,price) VALUES (?,?,?)",
                (name, cat, price), commit=True)
    return jsonify({"id": pid, "message": "Producto creado"}), 201

@app.route("/api/products/<int:pid>", methods=["PUT"])
@roles_required("Admin")
def update_product(pid):
    d = request.get_json() or {}
    fields, vals = [], []
    if d.get("name"):
        fields.append("name=?"); vals.append(d["name"].strip())
    if d.get("category_id"):
        fields.append("category_id=?"); vals.append(d["category_id"])
    if d.get("price") is not None:
        fields.append("price=?"); vals.append(d["price"])
    if "active" in d:
        fields.append("active=?"); vals.append(1 if d["active"] else 0)
    if not fields:
        return jsonify({"error": "Nada que actualizar"}), 400
    vals.append(pid)
    query(f"UPDATE products SET {','.join(fields)} WHERE id=?", vals, commit=True)
    return jsonify({"message": "Producto actualizado"})

@app.route("/api/products/<int:pid>", methods=["DELETE"])
@roles_required("Admin")
def delete_product(pid):
    in_active = query("""
        SELECT oi.id FROM order_items oi
        JOIN orders o ON oi.order_id=o.id
        WHERE oi.product_id=? AND o.status != 'entregado'
        LIMIT 1
    """, (pid,), one=True)
    if in_active:
        return jsonify({"error": "Producto en pedidos activos, no se puede eliminar"}), 400
    query("DELETE FROM products WHERE id=?", (pid,), commit=True)
    return jsonify({"message": "Producto eliminado"})


@app.route("/api/orders", methods=["GET"])
@token_required
def get_orders():
    status = request.args.get("status")
    if g.user_role == "Repartidor":
        if status:
            rows = query("""
                SELECT o.*, u.name as creator_name
                FROM orders o JOIN users u ON o.created_by=u.id
                WHERE o.status=? ORDER BY o.updated DESC
            """, (status,))
        else:
            rows = query("""
                SELECT o.*, u.name as creator_name
                FROM orders o JOIN users u ON o.created_by=u.id
                WHERE o.status IN ('listo','entregado') ORDER BY o.updated DESC
            """)
    elif status:
        rows = query("""
            SELECT o.*, u.name as creator_name
            FROM orders o JOIN users u ON o.created_by=u.id
            WHERE o.status=? ORDER BY o.updated DESC
        """, (status,))
    else:
        rows = query("""
            SELECT o.*, u.name as creator_name
            FROM orders o JOIN users u ON o.created_by=u.id
            ORDER BY o.updated DESC
        """)
    return jsonify(rows)

@app.route("/api/orders", methods=["POST"])
@roles_required("Admin", "Cocina")
def create_order():
    d = request.get_json() or {}
    notes = (d.get("notes") or "").strip()
    oid = query("INSERT INTO orders (created_by, notes) VALUES (?,?)",
                (g.user_id, notes or None), commit=True)
    return jsonify({"id": oid, "message": "Pedido creado"}), 201

@app.route("/api/orders/<int:oid>", methods=["GET"])
@token_required
def get_order(oid):
    order = query("SELECT o.*, u.name as creator_name FROM orders o JOIN users u ON o.created_by=u.id WHERE o.id=?", (oid,), one=True)
    if not order:
        return jsonify({"error": "Pedido no encontrado"}), 404
    items = query("""
        SELECT oi.id, oi.quantity, p.name as product_name, p.price,
               c.name as category_name
        FROM order_items oi
        JOIN products p ON oi.product_id=p.id
        JOIN categories c ON p.category_id=c.id
        WHERE oi.order_id=?
    """, (oid,))
    order["items"] = items
    return jsonify(order)

@app.route("/api/orders/<int:oid>/items", methods=["POST"])
@roles_required("Admin", "Cocina")
def add_item(oid):
    order = query("SELECT status FROM orders WHERE id=?", (oid,), one=True)
    if not order:
        return jsonify({"error": "Pedido no encontrado"}), 404
    if order["status"] != "pendiente":
        return jsonify({"error": "Solo se pueden agregar ítems a pedidos pendientes"}), 400
    d = request.get_json() or {}
    pid = d.get("product_id")
    qty = int(d.get("quantity", 1))
    if not pid or qty < 1:
        return jsonify({"error": "product_id y quantity requeridos"}), 400

    recipe = query("""
        SELECT r.ingredient_id, r.quantity * ? as needed, i.stock, i.name
        FROM recipes r JOIN ingredients i ON r.ingredient_id=i.id
        WHERE r.product_id=?
    """, (qty, pid))
    for r in recipe:
        if r["stock"] < r["needed"]:
            return jsonify({"error": f"Stock insuficiente: {r['name']} (disponible: {r['stock']}, necesita: {r['needed']})"}), 400

    db = get_db()
    for r in recipe:
        db.execute("UPDATE ingredients SET stock = stock - ? WHERE id=?",
                   (r["needed"], r["ingredient_id"]))
        db.execute("""
            INSERT INTO inventory_movements (ingredient_id, type, quantity, note, created_by)
            VALUES (?, 'salida', ?, ?, ?)
        """, (r["ingredient_id"], r["needed"], f"Pedido #{oid}", g.user_id))

    existing = query("SELECT id, quantity FROM order_items WHERE order_id=? AND product_id=?",
                     (oid, pid), one=True)
    if existing:
        db.execute("UPDATE order_items SET quantity=? WHERE id=?",
                   (existing["quantity"] + qty, existing["id"]))
    else:
        db.execute("INSERT INTO order_items (order_id, product_id, quantity) VALUES (?,?,?)",
                   (oid, pid, qty))
    db.commit()
    return jsonify({"message": "Ítem agregado"}), 201

@app.route("/api/orders/<int:oid>/status", methods=["PUT"])
@token_required
def update_order_status(oid):
    order = query("SELECT * FROM orders WHERE id=?", (oid,), one=True)
    if not order:
        return jsonify({"error": "Pedido no encontrado"}), 404

    d = request.get_json() or {}
    new_status = d.get("status")

    FLOW = {
        "pendiente":      "en preparacion",
        "en preparacion": "listo",
        "listo":          "entregado",
    }

    current = order["status"]

    if g.user_role == "Repartidor":
        if current != "listo" or new_status != "entregado":
            return jsonify({"error": "Repartidor solo puede marcar 'listo' como 'entregado'"}), 403
        query("UPDATE orders SET status=?, delivered_by=?, updated=datetime('now') WHERE id=?",
              ("entregado", g.user_id, oid), commit=True)
        return jsonify({"message": "Pedido marcado como entregado"})

    if g.user_role not in ("Admin", "Cocina"):
        return jsonify({"error": "Sin permiso"}), 403

    if new_status not in FLOW.values():
        return jsonify({"error": "Estado inválido"}), 400
    if FLOW.get(current) != new_status:
        return jsonify({"error": f"Flujo incorrecto: {current} → {new_status}"}), 400

    query("UPDATE orders SET status=?, updated=datetime('now') WHERE id=?",
          (new_status, oid), commit=True)
    return jsonify({"message": f"Estado actualizado a {new_status}"})

@app.route("/api/orders/<int:oid>", methods=["DELETE"])
@roles_required("Admin")
def delete_order(oid):
    order = query("SELECT status FROM orders WHERE id=?", (oid,), one=True)
    if not order:
        return jsonify({"error": "Pedido no encontrado"}), 404
    if order["status"] != "entregado":
        return jsonify({"error": "Solo se pueden eliminar pedidos entregados"}), 400
    query("DELETE FROM orders WHERE id=?", (oid,), commit=True)
    return jsonify({"message": "Pedido eliminado"})


@app.route("/api/ingredients", methods=["GET"])
@token_required
def get_ingredients():
    rows = query("SELECT * FROM ingredients ORDER BY name")
    return jsonify(rows)

@app.route("/api/ingredients", methods=["POST"])
@roles_required("Admin")
def create_ingredient():
    d = request.get_json() or {}
    name  = (d.get("name") or "").strip()
    unit  = (d.get("unit") or "unidad").strip()
    stock = float(d.get("stock", 0))
    if not name:
        return jsonify({"error": "Nombre requerido"}), 400
    iid = query("INSERT INTO ingredients (name,unit,stock) VALUES (?,?,?)",
                (name, unit, stock), commit=True)
    return jsonify({"id": iid, "message": "Ingrediente creado"}), 201

@app.route("/api/ingredients/<int:iid>", methods=["PUT"])
@roles_required("Admin")
def update_ingredient(iid):
    d = request.get_json() or {}
    fields, vals = [], []
    if d.get("name"):
        fields.append("name=?"); vals.append(d["name"].strip())
    if d.get("unit"):
        fields.append("unit=?"); vals.append(d["unit"].strip())
    if d.get("stock") is not None:
        fields.append("stock=?"); vals.append(float(d["stock"]))
    if not fields:
        return jsonify({"error": "Nada que actualizar"}), 400
    vals.append(iid)
    query(f"UPDATE ingredients SET {','.join(fields)} WHERE id=?", vals, commit=True)
    return jsonify({"message": "Ingrediente actualizado"})

@app.route("/api/ingredients/<int:iid>", methods=["DELETE"])
@roles_required("Admin")
def delete_ingredient(iid):
    in_recipe = query("SELECT id FROM recipes WHERE ingredient_id=? LIMIT 1", (iid,), one=True)
    if in_recipe:
        return jsonify({"error": "Ingrediente usado en recetas"}), 400
    query("DELETE FROM ingredients WHERE id=?", (iid,), commit=True)
    return jsonify({"message": "Ingrediente eliminado"})

@app.route("/api/ingredients/<int:iid>/stock", methods=["POST"])
@roles_required("Admin")
def add_stock(iid):
    d = request.get_json() or {}
    qty  = float(d.get("quantity", 0))
    note = (d.get("note") or "Entrada manual").strip()
    if qty <= 0:
        return jsonify({"error": "Cantidad debe ser positiva"}), 400
    db = get_db()
    db.execute("UPDATE ingredients SET stock = stock + ? WHERE id=?", (qty, iid))
    db.execute("""
        INSERT INTO inventory_movements (ingredient_id, type, quantity, note, created_by)
        VALUES (?, 'entrada', ?, ?, ?)
    """, (iid, qty, note, g.user_id))
    db.commit()
    return jsonify({"message": "Stock actualizado"})

@app.route("/api/inventory/movements", methods=["GET"])
@roles_required("Admin")
def get_movements():
    rows = query("""
        SELECT m.*, i.name as ingredient_name, u.name as user_name
        FROM inventory_movements m
        JOIN ingredients i ON m.ingredient_id=i.id
        LEFT JOIN users u ON m.created_by=u.id
        ORDER BY m.created DESC LIMIT 200
    """)
    return jsonify(rows)


@app.route("/api/recipes", methods=["GET"])
@token_required
def get_recipes():
    products = query("SELECT id, name FROM products WHERE active=1 ORDER BY name")
    result = []
    for p in products:
        ingredients = query("""
            SELECT r.id as recipe_id, r.quantity, i.id as ingredient_id,
                   i.name as ingredient_name, i.unit
            FROM recipes r JOIN ingredients i ON r.ingredient_id=i.id
            WHERE r.product_id=?
        """, (p["id"],))
        result.append({**p, "ingredients": ingredients})
    return jsonify(result)

@app.route("/api/recipes", methods=["POST"])
@roles_required("Admin")
def add_recipe_item():
    d = request.get_json() or {}
    pid  = d.get("product_id")
    iid  = d.get("ingredient_id")
    qty  = float(d.get("quantity", 1))
    if not pid or not iid:
        return jsonify({"error": "product_id e ingredient_id requeridos"}), 400
    db = get_db()
    try:
        db.execute("INSERT INTO recipes (product_id, ingredient_id, quantity) VALUES (?,?,?)",
                   (pid, iid, qty))
        db.commit()
    except sqlite3.IntegrityError:
        db.execute("UPDATE recipes SET quantity=? WHERE product_id=? AND ingredient_id=?",
                   (qty, pid, iid))
        db.commit()
    return jsonify({"message": "Receta actualizada"}), 201

@app.route("/api/recipes/<int:rid>", methods=["PUT"])
@roles_required("Admin")
def update_recipe_item(rid):
    d = request.get_json() or {}
    qty = float(d.get("quantity", 1))
    query("UPDATE recipes SET quantity=? WHERE id=?", (qty, rid), commit=True)
    return jsonify({"message": "Receta actualizada"})

@app.route("/api/recipes/<int:rid>", methods=["DELETE"])
@roles_required("Admin")
def delete_recipe_item(rid):
    query("DELETE FROM recipes WHERE id=?", (rid,), commit=True)
    return jsonify({"message": "Ingrediente quitado de receta"})


@app.route("/")
@app.route("/<path:path>")
def frontend(path=None):
    return send_from_directory("templates", "index.html")

if __name__ == "__main__":
    init_db()
    print("\n🍳 Cocina Oculta iniciando...")
    print("   URL: http://localhost:5000")
    print("   Admin: admin@cocina.com / admin123\n")
    app.run(debug=False, host="0.0.0.0", port=5000)
