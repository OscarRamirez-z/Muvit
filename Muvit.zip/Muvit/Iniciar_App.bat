@echo off
title Muvit
echo ================================================
echo   Muvit - Sistema de Gestion de Cocina
echo ================================================
echo.
python run.py
if %errorlevel% neq 0 (
    echo.
    echo ERROR: Asegurate de tener Python instalado.
    echo Descarga Python en: https://www.python.org
    pause
)
