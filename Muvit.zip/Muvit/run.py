import subprocess
import sys
import os
import time
import threading
import webbrowser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

REQUIRED = ["flask", "PyJWT"]

def check_and_install():
    import importlib
    missing = []
    for pkg in REQUIRED:
        try:
            importlib.import_module(pkg.lower().replace("-", "_"))
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f" Instalando dependencias: {', '.join(missing)}")
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "--break-system-packages",
            "--quiet", *missing
        ])
        print(" Dependencias instaladas")

def open_browser():
    time.sleep(1.5)
    webbrowser.open("http://localhost:5000")
    print("🌐 Navegador abierto en http://localhost:5000")

if __name__ == "__main__":
    print("=" * 50)
    print("  🍳  Muvit — Sistema de Gestión")
    print("=" * 50)
    check_and_install()
    os.chdir(BASE_DIR)
    threading.Thread(target=open_browser, daemon=True).start()
    # Importar y arrancar la app
    from app import app, init_db
    init_db()
    print("\n Bd funciona")
    print(" http://localhost:5000")
    print(" admin@cocina.com / admin123")
    app.run(debug=False, host="0.0.0.0", port=5000, use_reloader=False)
